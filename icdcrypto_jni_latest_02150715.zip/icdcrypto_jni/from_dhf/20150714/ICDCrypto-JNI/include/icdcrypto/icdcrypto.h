//
//  icdcrypto.h
//  icdcrypto
//
//  Created by dhf on 7/5/15.
//  Copyright (c) 2015 Cloudoor Technology Co.,Ltd. All rights reserved.
//

/**
 * 开门结果
 *
 */
extern const int DOOR_OPEN_SUCCESS; // 开门成功
extern const int DOOR_OPEN_FAIL; // 开门失败

/**
 * 解析门禁设备 ID 编号
 *
 * @param inBytes: 传入参数；发现门禁设备时，广播信息携带的 kCBAdvDataManufacturerData 内容
 * @param inLength: 传入参数；inBytes 的数组长度
 * @param outBytes: 传出参数；解码后的门禁设备 Id；*outBytes数组需要调用者手工回收内存
 * @param outLength: 传出参数；*outBytes 的数组长度
 *
 */
extern void decodeDoorDeviceId(const unsigned char * const inBytes, const unsigned int inLength, const unsigned char **outBytes, unsigned int *const outLength);

/**
 * 编码开门指令
 *
 * @param inBytes: 传入参数；门禁 "FFF1" 特性携带的内容
 * @param inLength: 传入参数；inBytes 的数组长度
 * @param outBytes: 传出参数；编码后的开门指令内容；*outBytes数组需要调用者手工回收内存
 * @param outLength: 传出参数；*outBytes 的数组长度
 *
 */
extern void encodeDoorOpenSignal(const unsigned char * const inBytes, const unsigned int inLength, const unsigned char **outBytes, unsigned int *const outLength);

/**
 * 解析开门结果
 *
 * @param inBytes: 传入参数；门禁 "FFF4" 特性携带的内容
 * @param inLength: 传入参数；inBytes 的数组长度
 * 
 * @return DOOR_OPEN_SUCCESS or DOOR_OPEN_FAIL
 *
 */
extern int decodeDoorOpenResult(const unsigned char * const inBytes, const unsigned int inLength);
