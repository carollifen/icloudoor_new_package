#include "ICDCrypto-JNI.h"
#include "include/icdcrypto/icdcrypto.h"
#include <stdio.h>
#include <stdlib.h>

jbyteArray as_byte_array(JNIEnv *env, const unsigned char *buf, int len) {
    jbyteArray array = (*env)->NewByteArray(env, len);
    (*env)->SetByteArrayRegion(env, array, 0, len, (jbyte*)(buf));
    return array;
}

unsigned char * as_unsigned_char_array(JNIEnv *env, jbyteArray array) {
    int len = (*env)->GetArrayLength(env, array);
    unsigned char *buf = malloc(sizeof(unsigned char)*len);
    (*env)->GetByteArrayRegion(env, array, 0, len, (jbyte*)(buf));
    return buf;
}

/*
 * Class:     ICDCrypto
 * Method:    decodeDoorDeviceId
 * Signature: ([B)[B
 */
JNIEXPORT jbyteArray JNICALL Java_ICDCrypto_decodeDoorDeviceId
  (JNIEnv *env, jobject obj, jbyteArray byteArr) {
    jsize arrLen = (*env)->GetArrayLength(env, byteArr);
    unsigned char *inBytes = as_unsigned_char_array(env, byteArr);
    unsigned int inLength = (unsigned int)arrLen;
    const unsigned char *outBytes;
    unsigned int outLength;
    decodeDoorDeviceId(inBytes, inLength, &outBytes, &outLength);
    jbyteArray result = as_byte_array(env, outBytes, outLength);
    free((void *)inBytes);
    free((void *)outBytes);
    return result;
}

/*
 * Class:     ICDCrypto
 * Method:    encodeDoorOpenSignal
 * Signature: ([B)[B
 */
JNIEXPORT jbyteArray JNICALL Java_ICDCrypto_encodeDoorOpenSignal
  (JNIEnv *env, jobject obj, jbyteArray byteArr) {
    jsize arrLen = (*env)->GetArrayLength(env, byteArr);
    unsigned char *inBytes = as_unsigned_char_array(env, byteArr);
    unsigned int inLength = (unsigned int)arrLen;
    const unsigned char *outBytes;
    unsigned int outLength;
    encodeDoorOpenSignal(inBytes, inLength, &outBytes, &outLength);
    jbyteArray result = as_byte_array(env, outBytes, outLength);
    free((void *)inBytes);
    free((void *)outBytes);
    return result;
}

/*
 * Class:     ICDCrypto
 * Method:    checkIfOpenDoorSuccess
 * Signature: ([B)Z
 */
JNIEXPORT jboolean JNICALL Java_ICDCrypto_checkIfOpenDoorSuccess
  (JNIEnv *env, jobject obj, jbyteArray byteArr) {
    jsize arrLen = (*env)->GetArrayLength(env, byteArr);
    unsigned char *inBytes = as_unsigned_char_array(env, byteArr);
    unsigned int inLength = (unsigned int)arrLen;
    int result = decodeDoorOpenResult(inBytes, inLength);
    free((void *)inBytes);
    return result == DOOR_OPEN_SUCCESS;
}
