public class ICDCrypto {
  public native byte[] decodeDoorDeviceId(byte[] inBytes);
  public native byte[] encodeDoorOpenSignal(byte[] inBytes);
  public native boolean checkIfOpenDoorSuccess(byte[] inBytes);

  static {
    System.loadLibrary("libICDCrypto-JNI");
  }
}
